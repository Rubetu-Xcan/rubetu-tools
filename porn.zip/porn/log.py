#coding=utf-8
# Tebas index html
# Github : https://github.com/Rubetu-Xcan
# Youtube : CANDRA - NM
# Mode By Rubetu Xcan
import os,sys,time,re,requests,json
from requests import post
from time import sleep
import itertools
import threading

x = '\x36\x56\x77\x46\x49\x32\x38\x42\x6b\x73\x48\x77\x68\x50\x6e\x32\x38'

def login(s):
    for c in s + "\n":
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(0.001)

def intro(s):
    for c in s + "\n":
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(0.002)
        
def succesbh(s):
    for c in s + "\n":
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(0.010)
        
def failed(s):
    for c in s + "\n":
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(0.009)

os.system('clear')
login("""\033[1;37m  ╦═╗╗ ╔╔╦╗╔═╗╗ ╔   ╗ ╔╔╦╗╔╦╗═╗
\033[1;37m  ╠═╝╠═╣ ║ ╚═╗╠═╣   ╠═╣ ║ ║║║ ║
\033[1;37m  ╩  ╝ ╚╚╩╝╚═╝╝ ╚   ╝ ╚ ╩ ╩ ╩ ╚═╝ 
\033[1;37m │\033[41;1m \033[1;37mBy: RubetuXcan |  Versi: 1.0 \033[00m\033[1;37m│
\033[1;31m╾\033[1;37m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[1;31m╼        
\033[1;31m • \033[1;37mGet the token from the link below!
\033[1;31m • \033[0;32mhttp://bit.ly/token-ghj\n""")
token = raw_input("\033[1;31m • \033[1;37mMasukan Token\033[1;31m: \033[0;32m")
if token ==x:
	succesbh('\033[1;31m • \033[0;32mLogin Succes')
	time.sleep(3)
	os.system('python2 phish.py')
else:
	failed('\033[1;31m • \033[1;31mLogin Failed!')
	time.sleep(2)
	os.system('python2 log.py')